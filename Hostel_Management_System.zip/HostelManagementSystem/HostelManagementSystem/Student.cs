﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HostelManagementSystem
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahesh\OneDrive\Documents\HostelMgmt.mdf;Integrated Security=True;Connect Timeout=30");
        void FillStudentDGV()
        {
            Con.Open();
            string myquery = "Select * from Student_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            StudentDGV.DataSource = ds.Tables[0];
            Con.Close();
        }


        /*void FillStudentDGV()
        {
            Con.Open();
            string myquery = "Select * from Studet_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            StudentDGV.DataSource = ds.Tables[0];
            Con.Close();
        }*/
        void FillRoomCombobox()
        {
            Con.Open();
            string query = " Select * from Room_tbl where RoomStatus = '"+"Active"+"' and Booked = '"+"free"+"'";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RoomNum", typeof(int));
            dt.Load(rdr);
            StudRoomCb.ValueMember = "RoomNum";
            StudRoomCb.DataSource = dt;

            Con.Close();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            StudPrn.Text = StudentDGV.SelectedRows[0].Cells[0].Value.ToString();
            StudName.Text = StudentDGV.SelectedRows[0].Cells[1].Value.ToString();
            FatherName.Text = StudentDGV.SelectedRows[0].Cells[2].Value.ToString();
            MotherName.Text = StudentDGV.SelectedRows[0].Cells[3].Value.ToString();
            AddressTb.Text = StudentDGV.SelectedRows[0].Cells[4].Value.ToString();
            CollegeTb.Text = StudentDGV.SelectedRows[0].Cells[5].Value.ToString();

        }

        private void Student_Load(object sender, EventArgs e)
        {
            FillStudentDGV();
            FillRoomCombobox();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        void updateBookedStatusOndelete()
        {
            Con.Open();
            String query = "Update Room_tbl set Booked = '" + "Free" + "' where RoomNum=" + StudRoomCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            // MessageBox.Show("Rooms Sucessfully Updated");
            Con.Close();
        }
        void updateBookedStatus()
        {
            Con.Open();
            String query = "Update Room_tbl set Booked = '"+"Busy"+"' where RoomNum= "+ StudRoomCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
           // MessageBox.Show("Rooms Sucessfully Updated");
            Con.Close();
        }
        private void button4_Click_1(object sender, EventArgs e)
        {

            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (StudPrn.Text == "" || StudName.Text == "" || FatherName.Text == "" || MotherName.Text == "" || AddressTb.Text== "" || CollegeTb.Text == "")
            {
                MessageBox.Show("No empty Filled Accepted");
            }
            else
            {
                
                Con.Open();
                String query = "insert into Student_tbl values('"+StudPrn.Text+"','"+StudName.Text+"','"+FatherName.Text+"','"+MotherName.Text+"','"+AddressTb.Text+"','"+CollegeTb.Text+"',"+StudRoomCb.SelectedValue.ToString()+",'"+StudStatusCb.SelectedItem.ToString()+"')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Studnet Sucessfully Added");
                Con.Close();
                updateBookedStatus();
                FillStudentDGV();
                FillRoomCombobox();

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (StudPrn.Text == "")
            {
                MessageBox.Show("Enter the Student Number");
            }
            else
            {

                Con.Open();
                String query = "delete from Student_tbl where StdPrn ='"+StudPrn.Text+"'";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student Sucessfully Deleted");
                Con.Close();
                updateBookedStatusOndelete();
                FillStudentDGV();
                FillRoomCombobox();
            }
        }

        private void StudPrn_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (StudPrn.Text == "")
            {
                MessageBox.Show("Enter the Studnet Number");
            }
            else
            {

                Con.Open();
                String query = "update Student_tbl set StdName='"+ StudName.Text+"',FatherName= '" + FatherName.Text + "',MotherName = '"+MotherName.Text+ "', StdAddress = '"+AddressTb.Text+"',College = '"+CollegeTb.Text+"',StdRoom = "+StudRoomCb.SelectedValue.ToString() +", StdStatus = '"+StudStatusCb.SelectedItem.ToString()+"' where StdPrn = '"+StudPrn.Text+"'";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student Sucessfully Updated");
                Con.Close();
                updateBookedStatus();
                FillStudentDGV();
                FillRoomCombobox();
            }
        }

        private void StudName_Enter(object sender, EventArgs e)
        {
            if(StudName.Text== "Student Name")
            {
                StudName.Text = "";
            }
        }

        private void FatherName_Enter(object sender, EventArgs e)
        {
            if (FatherName.Text == "Father Name")
            {
                FatherName.Text = "";
            }
        }

        private void MotherName_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MotherName_Enter(object sender, EventArgs e)
        {
            if (MotherName.Text == "Mother Name")
            {
                MotherName.Text = "";
            }
        }

        private void AddressTb_Enter(object sender, EventArgs e)
        {
            if (AddressTb.Text == "Address")
            {
                AddressTb.Text = "";
            }
        }

        private void CollegeTb_Enter(object sender, EventArgs e)
        {
            if (CollegeTb.Text == "College")
            {
                CollegeTb.Text = "";
            }
        }
    }
}
