﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HostelManagementSystem
{
    public partial class Fees : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahesh\OneDrive\Documents\HostelMgmt.mdf;Integrated Security=True;Connect Timeout=30");
        public Fees()
        {
            InitializeComponent();
        }
        public void fillPrnCb()
        {
            Con.Open();
            String query = " select StdPrn from Student_tbl";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("StdPrn", typeof(int));
            dt.Load(rdr);
            PrnCb.ValueMember = "StdPrn";
            PrnCb.DataSource = dt;

            Con.Close();

        }
        string studname, roomname;
        public void fecthdata()
        {
            Con.Open();
            String qurey = "Select * from Student_tbl where StdPrn ='"+PrnCb.SelectedValue.ToString()+"'";
            SqlCommand cmd = new SqlCommand(qurey, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                studname = dr["StdName"].ToString();
                roomname = dr["StdRoom"].ToString();
                StudentNameTb.Text = studname;
                RoomNumTb.Text = roomname;
            }
            Con.Close();

        }
        void FillFeesDGV()
        {
            Con.Open();
            string myquery = "Select * from Fees_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            PaymentDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (PaymentIdTb.Text == "")
            {
                MessageBox.Show("Enter the payment Id");
            }
            else
            {

                Con.Open();
                String query = "delete from Fees_tbl where Paymentid ="+PaymentIdTb.Text+"";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Payment Sucessfully Deleted");
                Con.Close();
                FillFeesDGV(); 
               // updateBookedStatusOndelete();
               // FillEmployeeDGV();
               // FillRoomCombobox();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (PaymentIdTb.Text == "")
            {
                MessageBox.Show("Enter the Payment Id");
            }
            else
            {
                Con.Open();
                String paymentperiode;
                paymentperiode = Periode.Value.Month.ToString() + Periode.Value.Year.ToString();
                SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Fees_tbl where StudentPrn = '" + PrnCb.SelectedValue.ToString() + "' and PaymentMonth = '" + paymentperiode+ "'", Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    MessageBox.Show("There is No Due for This Month ");
                }
                else
                {

                    Con.Open();
                    String paymentperiode;
                    paymentperiode = Periode.Value.Month.ToString() + Periode.Value.Year.ToString();
                    String query = "update Fees_tbl set StudentPrn='" + PrnCb.SelectedValue.ToString() + "',StudentName= '" + StudentNameTb.Text + "',StdRoom = '" + RoomNumTb.Text + "', PaymentMonth = '" + paymentperiode + "',Amount = " + AmountTb.Text + " where Paymentid = '" + PaymentIdTb.Text + "'";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Payment Sucessfully Updated");
                    Con.Close();
                    FillFeesDGV();

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (PaymentIdTb.Text == "" || StudentNameTb.Text == "" || PrnCb.Text == "" || AmountTb.Text == "" )
            {
                MessageBox.Show("No empty Filled Accepted");
            }
            else
            {
                String paymentperiode;
                paymentperiode = Periode.Value.Month.ToString() + Periode.Value.Year.ToString();
                Con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Fees_tbl where StudentPrn = '"+PrnCb.SelectedValue.ToString()+"' and PaymentMonth = '"+paymentperiode.ToString()+"'",Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString()=="1")
                {
                    MessageBox.Show("There is No Due for This Month ");
                }
                else
                {
                    
                 //   Con.Open();
                    String query = "insert into Fees_tbl values('" + PaymentIdTb.Text + "','" + PrnCb.SelectedValue.ToString() + "','" + StudentNameTb.Text + "'," + RoomNumTb.Text + ",'" +paymentperiode+ "','" + AmountTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Payment Sucessfully Added");
                   
                }
                Con.Close();
                FillFeesDGV();
               

            }
        }

        private void Fees_Load(object sender, EventArgs e)
        {
            fillPrnCb();
            FillFeesDGV();
        }

        private void PrnCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fecthdata();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            PaymentIdTb.Text = PaymentDGV.SelectedRows[0].Cells[0].Value.ToString();
            PrnCb.SelectedItem = PaymentDGV.SelectedRows[0].Cells[1].Value.ToString();
            StudentNameTb.Text = PaymentDGV.SelectedRows[0].Cells[2].Value.ToString();
            RoomNumTb.Text = PaymentDGV.SelectedRows[0].Cells[3].Value.ToString();
            AmountTb.Text = PaymentDGV.SelectedRows[0].Cells[5].Value.ToString();
           
        }
    }
}
