﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Data.SqlClient;

namespace HostelManagementSystem
{
    public partial class login : Form
    { 
        public string username;
        public string password;
        //public string Owner;
    
        public login()
        {
            InitializeComponent();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            username = textBox1.Text;
            password = textBox2.Text;
            if(username =="Mahesh" && password == "pass")
            {
                MessageBox.Show("Welcome Mahesh Sir");
                this.Hide();
                Form1 obj = new Form1();
                obj.Show();
            }
            else
            {
                MessageBox.Show("Unauthorised User");
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
          //  textBox2.Text = "";
           // textBox2.ForeColor = Color.Black;
            // textBox2.PasswordChar = '.';
        }
    }
}
