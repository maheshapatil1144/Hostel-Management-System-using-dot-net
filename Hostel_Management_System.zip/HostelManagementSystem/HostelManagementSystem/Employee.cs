﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace HostelManagementSystem
{
    public partial class Employee : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahesh\OneDrive\Documents\HostelMgmt.mdf;Integrated Security=True;Connect Timeout=30");
        public Employee()
        {
            InitializeComponent();
        }
        void FillEmployeeDGV()
        {
            Con.Open();
            string myquery = "Select * from Employee_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            EmployeeDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (EmpIdTb.Text == "" || EmpNameTb.Text == "" || EmpPhoneTb.Text == "" || EmpAddTb.Text== "" || EmpPositionCb.SelectedItem.ToString() == "" || EmpStatusCb.SelectedItem.ToString() == "")
            {
                MessageBox.Show("Fill All the Details");
            }
            else
            {

                Con.Open();
                String query = "update Employee_tbl set EmpName='" +EmpNameTb.Text + "',EmpPhone= '" + EmpPhoneTb.Text + "',EmpAddress = '" +EmpAddTb.Text + "', EmpPos = '" + EmpPositionCb.SelectedItem.ToString()+ "',EmpStatus = '" +EmpStatusCb.SelectedItem.ToString() + "' where Empid = '" + EmpIdTb.Text + "'";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Sucessfully Updated");
                Con.Close();
               // updateBookedStatus();
                FillEmployeeDGV();
            //    FillRoomCombobox();
            }
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            FillEmployeeDGV();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (EmpIdTb.Text == "" || EmpNameTb.Text == "" || EmpPhoneTb.Text == "")
            {
                MessageBox.Show("No empty Filled Accepted");
            }
            else
            {

                Con.Open();
                String query = "insert into Employee_tbl values('"+ EmpIdTb.Text +"','" + EmpNameTb.Text + "','" + EmpPhoneTb.Text + "','" + EmpAddTb.Text + "','" + EmpPositionCb.SelectedItem.ToString() + "','" + EmpStatusCb.SelectedItem.ToString() + "')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Sucessfully Added");
                Con.Close();
                FillEmployeeDGV();
                /*updateBookedStatus();
                FillStudentDGV();
                FillRoomCombobox();
*/
            }
        }

        private void EmpPhoneTb_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           
        }

        private void EmployeeDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            EmpIdTb.Text = EmployeeDGV.SelectedRows[0].Cells[0].Value.ToString();
            EmpNameTb.Text = EmployeeDGV.SelectedRows[0].Cells[1].Value.ToString();
            EmpPhoneTb.Text = EmployeeDGV.SelectedRows[0].Cells[2].Value.ToString();
            EmpAddTb.Text = EmployeeDGV.SelectedRows[0].Cells[3].Value.ToString();
            EmpPositionCb.Text = EmployeeDGV.SelectedRows[0].Cells[4].Value.ToString();
            EmpStatusCb.Text = EmployeeDGV.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (EmpIdTb.Text == "")
            {
                MessageBox.Show("Enter the Employee Id");
            }
            else
            {

                Con.Open();
                String query = "delete from Employee_tbl where Empid = '"+ EmpIdTb.Text +"'";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Sucessfully Deleted");
                Con.Close();
                FillEmployeeDGV();
               
            }
        }
    }
}
