﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HostelManagementSystem
{
    public partial class Rooms : Form
    {
        public Rooms()
        {
            InitializeComponent();
        }

         SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahesh\OneDrive\Documents\HostelMgmt.mdf;Integrated Security=True;Connect Timeout=30");
       void FillRoomDGV()
        { 
            Con.Open();
            string myquery = "Select * from Room_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            RoomDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
       
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Rooms_Load(object sender, EventArgs e)
        {
            FillRoomDGV();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }
        String RoomBooked;
        private void button1_Click(object sender, EventArgs e)
        {
            string roomstatus;
            if (RoomNumtb.Text == "")
            {
                MessageBox.Show("Enter the Room Number");
            }
            else
            {
                if (YesRadio.Checked == true)
                    roomstatus = "Busy";
                else
                    roomstatus = "Free";
                Con.Open();
                String query = "insert into Room_tbl values("+RoomNumtb.Text+",'"+RoomStatusCb.SelectedItem.ToString()+"','"+roomstatus+ "')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Rooms Sucessfully Added");
                Con.Close();
                FillRoomDGV();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (RoomNumtb.Text == "")
            {
                MessageBox.Show("Enter the Room Number");
            }
            else
            {
                
                Con.Open();
                String query = "delete from Room_tbl where RoomNum = "+RoomNumtb.Text+"";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Rooms Sucessfully Deleted");
                Con.Close();
                FillRoomDGV();
            }

        }

        private void RoomDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            RoomNumtb.Text = RoomDGV.SelectedRows[0].Cells[1].Value.ToString();
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            if (RoomNumtb.Text == "")
            {
                MessageBox.Show("Enter the Room Number");
            }
            else
            {

                if (YesRadio.Checked == true)
                    RoomBooked = "Busy";
                else
                    RoomBooked = "Free";
                Con.Open();
                String query = "update Room_tbl set RoomStatus='"+RoomStatusCb.SelectedItem.ToString()+"',Booked= '"+ RoomBooked + "'Where RoomNum = "+RoomNumtb.Text+"";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Rooms Sucessfully Updated");
                Con.Close();
                FillRoomDGV();
            }
        }

        private void RoomNumtb_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void RoomStatusCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        int stock = 0, key = 0;
        private void RoomDGV_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = RoomDGV.Rows[e.RowIndex];
            RoomNumtb.Text = row.Cells[1].Value.ToString();

            if(RoomNumtb.Text == "")
            {
                stock = 0;
                key = 0;

            }
            else
            {
                stock = Convert.ToInt32(row.Cells[2].Value.ToString());
                key = Convert.ToInt32(row.Cells[0].Value.ToString());

            }
        }
    }
}
